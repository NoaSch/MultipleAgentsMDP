package MultipleAgents;

/**
 * Created by noa on 29-Aug-16.
 */
public class tests {

   /* public static void main(String[] args) {
    /*   /* String s = "moveTo0,repair,moveTo1";
        String[] actions = s.split(",");
        for(int i =0; i < actions.length; i++)
        System.out.println(actions[i]);*/
     /*   vec.clear();
        String arr[] = new String[NUM_OF_AGENTS * (NUM_OF_SENSORS + 2)];
        int idx = 0;
        for (int i = 0; i < NUM_OF_AGENTS; i++) {
            arr[idx] = "Stay";
            idx++;
            arr[idx] = "Repair";
            idx++;
            for (int k = 0; k < NUM_OF_SENSORS; k++) {
                arr[idx] = "moveTo" + k;
                idx++;
            }
        }
        int r = 2;
        int n = arr.length;
        printCombination(arr, n, r);
        ArrayList<String[]> arrAns = removeDuplicates(vec);
        for (int i = 0; i < arrAns.size(); i++) {
            String[] sArr = arrAns.get(i);
            //System.out.println(Arrays.toString(sArr));
            String s = Arrays.toString(sArr);
            s = s.substring(1,s.length()-1);
            System.out.println(s);
*/
            // String s;
            // for (int j = 0; j < sArr.length; j++)

            //System.out.print(sArr[j] + " ");
            //System.out.println("");


     /*  String s = "moveTo1, stay";
        String [] arr = s.split(", ");
       System.out.println(Arrays.toString(arr));
        System.out.println(arr[0]);
        System.out.println(arr[1]);*/

       // }
  //  }
}
